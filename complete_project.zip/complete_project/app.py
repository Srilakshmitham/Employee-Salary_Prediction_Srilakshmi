from flask import Flask, render_template, request
import joblib
import numpy as np

app = Flask(__name__)

# Load model and encoders
model = joblib.load('model_selected_features.pkl')
encoders = joblib.load('label_encoders.pkl')

# Features in order
feature_names = ['age', 'education', 'occupation', 'workclass', 'marital-status', 'gender', 'hours-per-week']

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    try:
        # Get form data
        age = int(request.form['age'])
        hours = int(request.form['hours-per-week'])
        education = request.form['education']
        occupation = request.form['occupation']
        workclass = request.form['workclass']
        marital = request.form['marital-status']
        gender = request.form['gender']

        input_data = [age, education, occupation, workclass, marital, gender, hours]

        # Apply label encoders
        encoded = []
        for i, value in enumerate(input_data):
            if isinstance(value, str):
                encoder = encoders.get(feature_names[i])
                value = encoder.transform([value])[0] if encoder else value
            encoded.append(value)

        prediction = model.predict([encoded])[0]
        result = ">50K" if prediction == 1 else "<=50K"

        return render_template('index.html', prediction=result)

    except Exception as e:
        return render_template('index.html', prediction=f"Error: {str(e)}")

if __name__ == '__main__':
    app.run(debug=True)
